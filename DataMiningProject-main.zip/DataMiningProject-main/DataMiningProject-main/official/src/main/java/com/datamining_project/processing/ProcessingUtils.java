package com.datamining_project.processing;

import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;  // Decision Tree (J48 is Weka's implementation of C4.5)
import weka.classifiers.functions.Logistic;  // Logistic Regression
import weka.classifiers.bayes.NaiveBayes;  // Naive Bayes
import weka.classifiers.trees.RandomForest;  // Random Forest
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Discretize;  // Discretize filter for attributes
import weka.filters.unsupervised.attribute.NumericToNominal;  // Convert numeric class to nominal
import weka.classifiers.Evaluation;

public class ProcessingUtils {

    // Load the dataset from ARFF file (output1.arff)
    public static Instances loadDataset(String path) throws Exception {
        DataSource source = new DataSource(path);
        Instances dataset = source.getDataSet();
        if (dataset.classIndex() == -1)
            dataset.setClassIndex(dataset.numAttributes() - 1); // Set the last attribute as the class
        return dataset;
    }

    // Logistic Regression
    public static void runLogisticRegression(Instances data) throws Exception {
        // Apply discretization to the attributes (not the class attribute)
        Discretize discretize = new Discretize();
        discretize.setInputFormat(data);
        data = Filter.useFilter(data, discretize);  // Apply the discretization filter to the attributes

        // Convert the class attribute to nominal if it's numeric
        if (data.classAttribute().isNumeric()) {
            NumericToNominal numericToNominal = new NumericToNominal();
            numericToNominal.setAttributeIndices(String.valueOf(data.classIndex() + 1)); // 1-based index
            numericToNominal.setInputFormat(data);
            data = Filter.useFilter(data, numericToNominal);  // Apply the filter to convert class to nominal
            System.out.println("Class attribute is numeric. Converted to nominal...");
        }

        // Logistic Regression
        Logistic logistic = new Logistic();
        logistic.buildClassifier(data);
        Evaluation evaluation = new Evaluation(data);
        evaluation.evaluateModel(logistic, data);
        System.out.println("Logistic Regression Evaluation: \n" + evaluation.toSummaryString());
    }

    // Naive Bayes
    public static void runNaiveBayes(Instances data) throws Exception {
        // Apply discretization to the attributes (not the class attribute)
        Discretize discretize = new Discretize();
        discretize.setInputFormat(data);
        data = Filter.useFilter(data, discretize);  // Apply the discretization filter to the attributes

        // Convert the class attribute to nominal if it's numeric
        if (data.classAttribute().isNumeric()) {
            NumericToNominal numericToNominal = new NumericToNominal();
            numericToNominal.setAttributeIndices(String.valueOf(data.classIndex() + 1)); // 1-based index
            numericToNominal.setInputFormat(data);
            data = Filter.useFilter(data, numericToNominal);  // Apply the filter to convert class to nominal
            System.out.println("Class attribute is numeric. Converted to nominal...");
        }

        // Naive Bayes
        NaiveBayes naiveBayes = new NaiveBayes();
        naiveBayes.buildClassifier(data);
        Evaluation evaluation = new Evaluation(data);
        evaluation.evaluateModel(naiveBayes, data);
        System.out.println("Naive Bayes Evaluation: \n" + evaluation.toSummaryString());
    }

    // Decision Tree (J48 - C4.5)
    public static void runDecisionTree(Instances data) throws Exception {
        // Apply discretization to the attributes (not the class attribute)
        Discretize discretize = new Discretize();
        discretize.setInputFormat(data);
        data = Filter.useFilter(data, discretize);  // Apply the discretization filter to the attributes

        // Convert the class attribute to nominal if it's numeric
        if (data.classAttribute().isNumeric()) {
            NumericToNominal numericToNominal = new NumericToNominal();
            numericToNominal.setAttributeIndices(String.valueOf(data.classIndex() + 1)); // 1-based index
            numericToNominal.setInputFormat(data);
            data = Filter.useFilter(data, numericToNominal);  // Apply the filter to convert class to nominal
            System.out.println("Class attribute is numeric. Converted to nominal...");
        }

        // Decision Tree (J48)
        J48 decisionTree = new J48();
        decisionTree.buildClassifier(data);
        Evaluation evaluation = new Evaluation(data);
        evaluation.evaluateModel(decisionTree, data);
        System.out.println("Decision Tree Evaluation: \n" + evaluation.toSummaryString());
    }

    // Random Forest
    public static void runRandomForest(Instances data) throws Exception {
        // Apply discretization to the attributes (not the class attribute)
        Discretize discretize = new Discretize();
        discretize.setInputFormat(data);
        data = Filter.useFilter(data, discretize);  // Apply the discretization filter to the attributes

        // Convert the class attribute to nominal if it's numeric
        if (data.classAttribute().isNumeric()) {
            NumericToNominal numericToNominal = new NumericToNominal();
            numericToNominal.setAttributeIndices(String.valueOf(data.classIndex() + 1)); // 1-based index
            numericToNominal.setInputFormat(data);
            data = Filter.useFilter(data, numericToNominal);  // Apply the filter to convert class to nominal
            System.out.println("Class attribute is numeric. Converted to nominal...");
        }

        // Random Forest
        RandomForest randomForest = new RandomForest();
        randomForest.buildClassifier(data);
        Evaluation evaluation = new Evaluation(data);
        evaluation.evaluateModel(randomForest, data);
        System.out.println("Random Forest Evaluation: \n" + evaluation.toSummaryString());
    }
}
