package com.datamining_project;

import com.datamining_project.pre_processing.Preprocess;
import com.datamining_project.processing.ProcessingUtils;
import weka.core.Instances;

public class Main {
    public static void main(String[] args) throws Exception {
        new Preprocess();
        // Load the processed dataset (output1.arff) from the data folder
        String datasetPath = "C:\\Users\\bin\\Downloads\\DataMiningProject-main\\DataMiningProject-main\\official\\src\\main\\java\\com\\datamining_project\\data\\pre_processing\\output1.arff";
        Instances data = ProcessingUtils.loadDataset(datasetPath);  // Load the data

        // Run the models
        System.out.println("Running Logistic Regression...");
        ProcessingUtils.runLogisticRegression(data);

        System.out.println("Running Naive Bayes...");
        ProcessingUtils.runNaiveBayes(data);

        System.out.println("Running Decision Tree...");
        ProcessingUtils.runDecisionTree(data);

        System.out.println("Running Random Forest...");
        ProcessingUtils.runRandomForest(data);
    }
}
