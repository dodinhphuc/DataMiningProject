package com.datamining_project.constants;

public class Constants {
    public static final String INPUT_PATH = "C:\\Users\\bin\\Downloads\\DataMiningProject-main\\DataMiningProject-main\\official\\src\\main\\java\\com\\datamining_project\\data\\HepatitisCdata.csv";
    public static final String OUTPUT_PATH = "C:\\Users\\bin\\Downloads\\DataMiningProject-main\\DataMiningProject-main\\official\\src\\main\\java\\com\\datamining_project\\data\\pre_processing\\output1.arff";
}